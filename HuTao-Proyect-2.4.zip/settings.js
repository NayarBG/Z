import fs from 'fs';
import chalk from 'chalk';

global.owner = ['5218711426787']
global.sessionName = 'Sessions/Owner'
global.version = '^2.0'
global.pairing_code = true
global.number_bot = ''

global.api = {
  url: 'https://api.stellarwa.xyz',
  key: 'proyectsV2'
}

global.bot = {
  api: 'https://api.stellarwa.xyz',
  web: 'https://github.com/CheirZ'
}

global.mods = ['5218711426787']

global.msgglobal = '[Error: *TypeError*] fetch failed'
globalThis.dev = '★彡[xɪ_ᴍɪɢᴜᴇʟᴏɴ77xx]彡★'

global.mess = {
  socket: '《✧》 Este comando solo puede ser ejecutado por un Socket.',
  admin: '《✧》 Este comando solo puede ser ejecutado por los Administradores del Grupo.',
  botAdmin: '《✧》 Este comando solo puede ser ejecutado si el Socket es Administrador del Grupo.'
}

global.my = {
  ch: '120363371018732371@newsletter',
  name: 'HuTao Proyect - Official Channel 🫛🥙'
}
